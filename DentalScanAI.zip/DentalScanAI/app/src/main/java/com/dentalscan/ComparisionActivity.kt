package com.dentalscan

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dentalscan.data.AppDatabase
import com.dentalscan.data.ScanEntity
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

class ComparisonActivity : AppCompatActivity() {

    private lateinit var userSpinner: Spinner
    private lateinit var conditionSpinner: Spinner
    private lateinit var chart: LineChart
    private lateinit var beforeImage: ImageView
    private lateinit var afterImage: ImageView
    private lateinit var beforeDate: TextView
    private lateinit var afterDate: TextView
    private lateinit var improvementText: TextView

    private var allScans: List<ScanEntity> = emptyList()
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comparison)

        initViews()
        loadData()
    }

    private fun initViews() {
        userSpinner = findViewById(R.id.userSpinner)
        conditionSpinner = findViewById(R.id.conditionSpinner)
        chart = findViewById(R.id.trendChart)
        beforeImage = findViewById(R.id.beforeImage)
        afterImage = findViewById(R.id.afterImage)
        beforeDate = findViewById(R.id.beforeDate)
        afterDate = findViewById(R.id.afterDate)
        improvementText = findViewById(R.id.improvementText)

        conditionSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listOf("All Conditions", "Caries", "Plaque", "Calculus")
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        conditionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateComparison()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun loadData() {
        lifecycleScope.launch(Dispatchers.IO) {
            val database = AppDatabase.getDatabase(this@ComparisonActivity)
            val users = database.scanDao().getAllUsers()

            withContext(Dispatchers.Main) {
                userSpinner.adapter = ArrayAdapter(
                    this@ComparisonActivity,
                    android.R.layout.simple_spinner_item,
                    listOf("Select User") + users.map { it.userName }
                ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

                userSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        if (position > 0) {
                            loadUserScans(users[position - 1].userId)
                        }
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
        }
    }

    private fun loadUserScans(userId: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            val database = AppDatabase.getDatabase(this@ComparisonActivity)
            database.scanDao().getScansForUser(userId).first().let { scans ->
                allScans = scans
                withContext(Dispatchers.Main) {
                    updateComparison()
                }
            }
        }
    }

    private fun updateComparison() {
        if (allScans.size < 2) {
            improvementText.text = "Need at least 2 scans for comparison"
            return
        }

        val conditionFilter = conditionSpinner.selectedItem.toString()
        val filteredScans = if (conditionFilter == "All Conditions") {
            allScans
        } else {
            allScans.filter { it.condition == conditionFilter }
        }.sortedBy { it.timestamp }

        if (filteredScans.size < 2) {
            improvementText.text = "Not enough scans for this condition"
            return
        }

        val firstScan = filteredScans.first()
        val latestScan = filteredScans.last()

        beforeImage.setImageBitmap(BitmapFactory.decodeFile(firstScan.imagePath))
        afterImage.setImageBitmap(BitmapFactory.decodeFile(latestScan.imagePath))

        beforeDate.text = "Before: ${dateFormat.format(firstScan.timestamp)}"
        afterDate.text = "After: ${dateFormat.format(latestScan.timestamp)}"

        val improvement = calculateImprovement(filteredScans)
        improvementText.text = when {
            improvement > 20 -> "✓ Significant improvement! Keep up the good oral hygiene."
            improvement > 0 -> "→ Slight improvement noted."
            improvement > -20 -> "→ Stable condition. Maintain current routine."
            else -> "⚠ Condition worsening. Please consult a dentist."
        }

        updateTrendChart(filteredScans)
    }

    private fun calculateImprovement(scans: List<ScanEntity>): Float {
        val earlySevere = scans.take(scans.size / 2).count { it.severity == "High" }
        val recentSevere = scans.takeLast(scans.size / 2).count { it.severity == "High" }

        return if (earlySevere == 0) 0f
        else ((earlySevere - recentSevere).toFloat() / earlySevere) * 100
    }

    private fun updateTrendChart(scans: List<ScanEntity>) {
        val entries = scans.mapIndexed { index, scan ->
            val severityScore = when (scan.severity) {
                "High" -> 3f
                "Medium" -> 2f
                "Low" -> 1f
                else -> 0f
            }
            Entry(index.toFloat(), severityScore)
        }

        val dataSet = LineDataSet(entries, "Dental Health Trend").apply {
            color = resources.getColor(android.R.color.holo_blue_dark, theme)
            setCircleColor(resources.getColor(android.R.color.holo_red_dark, theme))
            lineWidth = 2f
            circleRadius = 4f
        }

        chart.data = LineData(dataSet)
        chart.description.text = "Lower is better"
        chart.invalidate()
    }
}