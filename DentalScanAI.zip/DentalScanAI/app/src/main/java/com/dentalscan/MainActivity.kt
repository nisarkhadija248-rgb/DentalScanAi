package com.dentalscan

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.dentalscan.utils.VoiceFeedback

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Force Urdu mode for testing
        getSharedPreferences("settings", MODE_PRIVATE)
            .edit()
            .putBoolean("urdu_language", true)
            .apply()
// Language toggle button
        findViewById<Button>(R.id.btnLanguage)?.setOnClickListener {
            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
            val isUrdu = !prefs.getBoolean("urdu_language", false)
            prefs.edit().putBoolean("urdu_language", isUrdu).apply()

            VoiceFeedback.setLanguage(isUrdu)

            // Restart activity to apply language
            recreate()
        }
        VoiceFeedback.initialize(this)

        findViewById<Button>(R.id.btnStartScan).setOnClickListener {
            startActivity(Intent(this, CameraActivity::class.java))
        }

        findViewById<Button>(R.id.btnHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        findViewById<Button>(R.id.btnCompare).setOnClickListener {
            startActivity(Intent(this, ComparisonActivity::class.java))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        VoiceFeedback.shutdown()
    }
}