package com.dentalscan

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dentalscan.adapter.ScanHistoryAdapter
import com.dentalscan.data.AppDatabase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ScanHistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = ScanHistoryAdapter { scan ->
            // Handle item click - could open detail view
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        loadScans()
    }

    private fun loadScans() {
        lifecycleScope.launch {
            val database = AppDatabase.getDatabase(this@HistoryActivity)
            val userId = getSharedPreferences("settings", MODE_PRIVATE)
                .getString("current_user_id", "user_1") ?: "user_1"

            database.scanDao().getScansForUser(userId).first().let { scans ->
                adapter.submitList(scans)
            }
        }
    }
}