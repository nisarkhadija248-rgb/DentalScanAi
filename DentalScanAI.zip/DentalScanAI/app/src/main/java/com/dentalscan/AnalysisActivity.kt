package com.dentalscan

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dentalscan.data.AppDatabase
import com.dentalscan.data.ScanEntity
import com.dentalscan.ml.TFLiteHelper
import com.dentalscan.utils.ImageUtils
import com.dentalscan.utils.VoiceFeedback
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AnalysisActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var resultText: TextView
    private lateinit var confidenceText: TextView
    private lateinit var saveButton: Button
    private lateinit var retakeButton: TextView

    private var tfliteHelper: TFLiteHelper? = null
    private var currentDetections: List<TFLiteHelper.Detection> = emptyList()
    private var imagePath: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analysis)

        imageView = findViewById(R.id.resultImageView)
        resultText = findViewById(R.id.resultText)
        confidenceText = findViewById(R.id.confidenceText)
        saveButton = findViewById(R.id.saveButton)
        retakeButton = findViewById(R.id.retakeButton)

        imagePath = intent.getStringExtra("image_path") ?: return

        analyzeImage()

        saveButton.setOnClickListener { saveScan() }
        retakeButton.setOnClickListener { finish() }
    }

    private fun analyzeImage() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                tfliteHelper = TFLiteHelper(this@AnalysisActivity)

                val bitmap = BitmapFactory.decodeFile(imagePath)
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap, 640, 640, true)

                currentDetections = tfliteHelper?.detect(scaledBitmap) ?: emptyList()

                val resultBitmap = ImageUtils.drawDetections(scaledBitmap, currentDetections)

                val primaryDetection = currentDetections.maxByOrNull { it.confidence }

                withContext(Dispatchers.Main) {
                    imageView.setImageBitmap(resultBitmap)
                    displayResults(primaryDetection)
                }

            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    resultText.text = "Analysis error. Please try again."
                }
            }
        }
    }

    private fun displayResults(detection: TFLiteHelper.Detection?) {
        if (detection == null) {
            resultText.text = "No dental issues detected"
            confidenceText.text = "Your teeth appear healthy"
            VoiceFeedback.speak("No dental issues detected. Your teeth appear healthy.")
            return
        }

        val condition = detection.className
        val confidence = (detection.confidence * 100).toInt()
        val severity = ImageUtils.getSeverityText(detection.confidence)

        resultText.text = "$condition Detected"
        confidenceText.text = "Confidence: $confidence% ($severity)"

        val isUrdu = getSharedPreferences("settings", MODE_PRIVATE)
            .getBoolean("urdu_language", false)
        VoiceFeedback.speakDetectionResult(condition, severity, isUrdu)

        val isUrdu = getSharedPreferences("settings", MODE_PRIVATE)
            .getBoolean("urdu_language", false)
        val guidance = ImageUtils.getGuidanceMessage(condition, isUrdu)

        lifecycleScope.launch {
            kotlinx.coroutines.delay(3000)
            VoiceFeedback.speak(guidance)
        }
    }

    private fun saveScan() {
        val detection = currentDetections.maxByOrNull { it.confidence } ?: return

        val scan = ScanEntity(
            userId = getCurrentUserId(),
            userName = getCurrentUserName(),
            imagePath = imagePath,
            condition = detection.className,
            confidence = detection.confidence,
            severity = ImageUtils.getSeverityText(detection.confidence),
            boundingBoxes = detectionsToJson(currentDetections)
        )

        lifecycleScope.launch(Dispatchers.IO) {
            AppDatabase.getDatabase(this@AnalysisActivity)
                .scanDao()
                .insertScan(scan)

            withContext(Dispatchers.Main) {
                VoiceFeedback.speak("Scan saved successfully")
                finish()
            }
        }
    }

    private fun detectionsToJson(detections: List<TFLiteHelper.Detection>): String {
        val jsonArray = JSONArray()
        detections.forEach { d ->
            val obj = JSONObject().apply {
                put("class", d.className)
                put("confidence", d.confidence)
                put("x", d.boundingBox.centerX())
                put("y", d.boundingBox.centerY())
                put("width", d.boundingBox.width())
                put("height", d.boundingBox.height())
            }
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }

    private fun getCurrentUserId(): String {
        return getSharedPreferences("settings", MODE_PRIVATE)
            .getString("current_user_id", "user_1") ?: "user_1"
    }

    private fun getCurrentUserName(): String {
        return getSharedPreferences("settings", MODE_PRIVATE)
            .getString("current_user_name", "Default User") ?: "Default User"
    }

    override fun onDestroy() {
        super.onDestroy()
        tfliteHelper?.close()
    }
}