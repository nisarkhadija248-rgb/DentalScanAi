package com.dentalscan.ml

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF

class TFLiteHelper(context: Context) {

    data class Detection(
        val classId: Int,
        val className: String,
        val confidence: Float,
        val boundingBox: RectF
    )

    fun detect(image: Bitmap): List<Detection> {
        // DUMMY DETECTION for testing
        return listOf(
            Detection(
                classId = 0,
                className = "Caries",
                confidence = 0.85f,
                boundingBox = RectF(0.3f, 0.3f, 0.7f, 0.7f)
            )
        )
    }

    fun close() {
        // Nothing to close in dummy mode
    }
}