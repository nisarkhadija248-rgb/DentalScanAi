package com.dentalscan.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import java.util.Date

@Entity(tableName = "scans")
@TypeConverters(Converters::class)
data class ScanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String,
    val userName: String,
    val imagePath: String,
    val timestamp: Date = Date(),
    val condition: String,
    val confidence: Float,
    val severity: String,
    val boundingBoxes: String = "",
    val notes: String = ""
)